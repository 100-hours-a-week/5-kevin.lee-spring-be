package org.example.spring_be.controller;

public class CommentController {
}
